module.exports = [
    require('./searchApiController.js'),
    require('./buyApiController.js'),
    require('./booksApiController.js')
];
