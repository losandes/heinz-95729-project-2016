module.exports = [
    require('./homeController.js'),
    require('./authController.js')
];
