web
==========

## Getting Started
Before running this app, install the NPM and bower dependencies:
```Shell
> npm run install-dependencies
```

After that, you can run the app using ``npm start``.

## Directories
The express app has the following directory structure:
```
- controllers
- public
- views
```
